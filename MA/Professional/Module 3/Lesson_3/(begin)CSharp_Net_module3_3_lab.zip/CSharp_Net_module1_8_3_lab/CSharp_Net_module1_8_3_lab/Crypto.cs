﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CSharp_Net_module1_8_3_lab
{
    class Crypto
    {
        // 1) Change parameters in method and returned type
        public void Crypting()
        {
            // 2) Create crypto provider object
            // use class MD5CryptoServiceProvider


            // 3) Create crypto hash by invoking method ComputeHash() of class MD5CryptoServiceProvider


            // 4) Add encrypted data to new string in hexadesimal form
            

            // Note1: use array of bytes as encrypted value (convert string to byte and vise versa)

            // Note2: use numeric format "x" to represent data in hexadesimal form. 
            // Number of digits in in the result string must be 2 (use precision)


            // 5) Save encrypted data to file

        }

        // 6) Change parameters in method and returned type
        public void Check()
        {
            // 7) Create crypto provider object
            // use class MD5CryptoServiceProvider


            // 8) Create crypto hash by invoking method ComputeHash() of class MD5CryptoServiceProvider


            // 9) Add encrypted data to new string in hexadesimal form


            // Note1: use array of bytes as encrypted value (convert string to byte and vise versa)

            // Note2: use numeric format "x" to represent data in hexadesimal form. 
            // Number of digits in in the result string must be 2 (use precision)

            // 10) Read data from the file


            // 11) compare crypted data and file data

        }

        // 12) Change parameters in method and returned type
        public void Signaturing()
        {
            // 13) use class CngKey to create signature key (declare object and invoke method Create())
            // use as parameter of method Create() some value of class CngAlgorithm (any algorythm)


            // 14) Create public key as array of bytes. Use method Export() of class CngKey, which will return byte array
            // use CngKeyBlobFormat.GenericPublicBlob as parameter


            // 15) Create signatere. Save it to array of bytes.
            //  Declare object of class ECDsaCng. Use declared object of CngKey as parameter of constructor.
            // Save to byte array result of method SignData() of class ECDsaCng with value of public key as parameter 

            // Note: don't forget to clear with method Clear() of class ECDsaCng
            
        }

        // 16) Change parameters in method and returned type
        // method must use created signature public key and signature 
        public void VerifySignature()
        {
            // 17) Use class CngKey to create new signature key to check data (declare object and invoke method Import());
            // use as parameter of method Import() values of signature public key, and the same format as in creating of signature key
            // (use CngKeyBlobFormat.GenericPublicBlob)

            // 18) Verify input data. Declare new object of class ECDsaCng with created signature key on prevous step

            // 19) Invoke method VerifyData() to verify input data;
            // 1st parameter - input data (as byte array)
            // 2nd parameter - created aerlier signature (in method Signaturing())


            // Note: don't forget to clear with method Clear() of class ECDsaCng
        }
    }
}
