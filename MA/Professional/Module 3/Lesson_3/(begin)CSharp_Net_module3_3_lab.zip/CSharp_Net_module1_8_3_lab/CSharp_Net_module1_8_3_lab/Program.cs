﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CSharp_Net_module1_8_3_lab
{
    class Program
    {
        static void Main(string[] args)
        {
            //20) Invoke methods and print results
        }
    }
}
