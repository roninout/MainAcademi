﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using AirplaneLibrary;

namespace CSharp_Net_module1_5_2_lab
{
    class Program
    {
        static void Main(string[] args)
        {
            //implement  CheckSaveTrace in using block

            {
                //create the  CargoAirplane and UniversalAirplane objects

                    //call CheckClassAttribute, SaveTrace and EventLogging methods
                    //for the  CargoAirplane and UniversalAirplane objects

            }
            Console.ReadKey();
        }
    }
}
