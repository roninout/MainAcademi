﻿using System;
using System.Diagnostics;
using AirplaneLibrary;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CSharp_Net_module1_5_2_lab
{
    //immplement class CheckSaveTrace:IDisposable
   
        //define  TraceSource and EventLog  fields


        //implement CheckSaveTrace() constructor with two methods calling
        //    initEventLog with assembly name as argument
        //    initTrace with assembly name as argument


        //implement Dispose(bool disposing) method


        //implement Dispose() method


        //implement ~CheckSaveTrace()


        //implement initEventLog method with assembly name as argument


        //implement   initTrace  method with assembly name as argument


        //implement  CheckClassAttribute(object obj) method
        //for  attributes output


        //implement SaveTrace(object obj) method
        //for obj attributes tracing


        //implement EventLogging(object obj) method
        //for obj attributes logging

}
