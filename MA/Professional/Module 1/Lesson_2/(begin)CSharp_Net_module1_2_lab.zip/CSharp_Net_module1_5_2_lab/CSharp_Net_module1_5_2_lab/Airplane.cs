﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CSharp_Net_module1_5_2_lab
{
    class Airplane
    {
        public Airplane()
        {
            Console.WriteLine("This is airplane");
        }
    }
}
